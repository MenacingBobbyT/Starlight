This is the 3rd Year project I worked on as part of a group of 3. Is is a rougelike game that has
random terain geration and dungen generation. 

This project recived a grade of A. 

The project is not finished as some of the features are either not there or incomplete.

Console Window
The console window is mainly for debug purposes but shows the layout of the maps better than the standard game screen.
Controls
Movement
W	  or	UPArrow         moveup
S	  or	Down arrow	    move down
A	  or	Left Arrow	    move left
D	  or	Right Arrow 	move right
Actions
Space	attack
Left Click	pickup weapon
Esc	exit game
Toggle Options
C	show player stats
I	show player inventory
M	prints map to console
P	pause/unpause game
F1	highlights all obstacles
F2	show bounds boxes
F3	show enemy paths
